const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express(); // 先初始化 app
const PORT = 3000;

// 中间件
app.use(cors());
app.use(bodyParser.json());

// MySQL 连接
const db = mysql.createConnection({
  host: '103.150.10.11',  // 不要加 http:// 或 https://
  port: 23004,
  user: 'root', // 数据库用户名
  password: 'root', // 数据库密码
  database: 'zy-tsglxt' // 数据库名称
});

// 连接到数据库
db.connect((err) => {
  if (err) throw err;
  console.log('成功连接到 MySQL 数据库...');
});

// 注册用户
app.post('/api/register', (req, res) => {
  const { username, password } = req.body;

  // 先检查用户名是否已存在
  const checkUserSql = 'SELECT * FROM user WHERE username = ?';
  db.query(checkUserSql, [username], (err, results) => {
    if (err) {
      console.error('查询失败:', err);
      return res.status(500).json({ message: '查询失败' });
    }

    if (results.length > 0) {
      // 用户名已存在
      console.log('用户名已存在');
      return res.status(409).json({ message: '用户名已存在' });
    }

    // 用户名不存在，执行插入操作
    const insertUserSql = 'INSERT INTO user (username, password) VALUES (?, ?)';
    db.query(insertUserSql, [username, password], (err, result) => {
      if (err) {
        console.error('注册失败:', err);
        return res.status(500).json({ message: '注册失败' });
      }

      console.log('注册成功:', result);
      res.status(200).json({ message: '注册成功', success: true });
    });
  });
});


// 用户登录
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const sql = 'SELECT * FROM user WHERE username = ? AND password = ?';
  db.query(sql, [username, password], (err, results) => {
    if (err) {
      console.error('登录失败:', err);
      return res.status(500).json(err);
    }
    if (results.length > 0) {
      res.status(200).json({ message: '登录成功', user: results[0] });
    } else {
      console.log('用户名或密码错误');
      res.status(401).json({ message: '用户名或密码错误' });
    }
  });
});

// 管理员登录
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  console.log('req.body', req.body);
  // 检查管理员的用户名和密码
  if (username === 'admin' && password === '1') {
    const admin = {
      username
    }
    console.log('管理员登录成功');
    return res.status(200).json({ message: '管理员登录成功', admin });
  }
  console.log('管理员用户名或密码错误');
  res.status(401).json({ message: '管理员用户名或密码错误' });
});

// 添加书籍
app.post('/api/books', (req, res) => {
  const { name, author, category, quantity, remark } = req.body;
  const sql = 'INSERT INTO books (name, author, category, quantity, remark) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [name, author, category, quantity, remark], (err, result) => {
    if (err) {
      console.error('添加书籍失败:', err);
      return res.status(500).json(err);
    }
    console.log('书籍添加成功:', result);
    res.status(200).json({ message: '书籍添加成功' });
  });
});

// 查询所有书籍
// app.get('/api/books', (req, res) => {
//     const sql = 'SELECT * FROM books';
//     db.query(sql, (err, results) => {
//         if (err) {
//             console.error('查询书籍失败:', err);
//             return res.status(500).json(err);
//         }
//         console.log('查询到书籍:', results);
//         res.status(200).json(results);
//     });
// });
app.get('/api/books', (req, res) => {
  let sql = 'SELECT * FROM books';
  if (req.query && req.query.name) {
    sql += ` where name like '%${req.query.name}%'`;
  }
  console.log('req.query', req.query, sql)
  db.query(sql, (err, results) => {
    if (err) {
      console.error('查询书籍失败:', err);
      return res.status(500).json(err);
    }
    console.log('查询到书籍:', results);
    res.status(200).json(results);
  });
});


// 编辑书籍
app.put('/api/books/:id', (req, res) => {
  const { id } = req.params;
  const { name, author, category, quantity, remark } = req.body;
  const sql = 'UPDATE books SET name = ?, author = ?, category = ?, quantity = ?, remark = ? WHERE id = ?';
  db.query(sql, [name, author, category, quantity, remark, id], (err, result) => {
    if (err) {
      console.error('更新书籍失败:', err);
      return res.status(500).json(err);
    }
    console.log('书籍信息更新成功:', result);
    res.status(200).json({ message: '书籍信息更新成功' });
  });
});



// 删除书籍
app.delete('/api/books/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM books WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('删除书籍失败:', err);
      return res.status(500).json(err);
    }
    console.log('书籍删除成功:', result);
    res.status(200).json({ message: '书籍删除成功' });
  });
});

// 借书功能
app.post('/api/borrow', (req, res) => {
  const { user_id, book_id } = req.body;
  console.log('req.body', req.body);
  const curDatetime = new Date().toLocaleString()
  const sql = `INSERT INTO borrow_records (user_id, book_id, borrow_time, status) VALUES (?, ?, '${curDatetime}', "未还")`;
  db.query(sql, [user_id, book_id], (err, result) => {
    if (err) {
      console.error('借书失败:', err);
      return res.status(500).json(err);
    }
    // 更新书籍可用数量
    const updateSql = 'UPDATE books SET quantity = quantity - 1 WHERE id = ?';
    db.query(updateSql, [book_id], (err) => {
      if (err) {
        console.error('更新书籍数量失败:', err);
        return res.status(500).json(err);
      }
      console.log('借书成功:', result);
      res.status(200).json({ message: '借书成功' });
    });
  });
});

// 还书功能
app.post('/api/return', (req, res) => {
  const { user_id, book_id } = req.body;
  console.log('req.body', req.body);
  const curDatetime = new Date().toLocaleString()
  const sql = `UPDATE borrow_records SET return_time = '${curDatetime}', status = "已还" WHERE user_id = ? AND book_id = ? AND status = "未还"`;
  console.log('sql', sql)
  db.query(sql, [user_id, book_id], (err, result) => {
    if (err) {
      console.error('还书失败:', err);
      return res.status(500).json(err);
    }
    // 更新书籍可用数量
    const updateSql = 'UPDATE books SET quantity = quantity + 1 WHERE id = ?';
    db.query(updateSql, [book_id], (err) => {
      if (err) {
        console.error('更新书籍数量失败:', err);
        return res.status(500).json(err);
      }
      console.log('还书成功:', result);
      res.status(200).json({ message: '还书成功' });
    });
  });
});

// 查询借阅记录
app.get('/api/borrow_records/:user_id', (req, res) => {
  const { user_id } = req.params;
  const { status } = req.query;
  const sql = `
        SELECT br.*, b.name AS book_name, b.author, b.category,b.remark
        FROM borrow_records br
        JOIN books b ON br.book_id = b.id
        WHERE br.user_id = ? and br.status = ?`;
  db.query(sql, [user_id, status], (err, results) => {
    if (err) {
      console.error('查询借阅记录失败:', err);
      return res.status(500).json(err);
    }
    console.log('查询到借阅记录:', results);
    res.status(200).json(results);
  });
});

// 获取用户数据
app.get('/get-user', (req, res) => {
  let sql = 'SELECT id, username, password FROM user'; // 查询 user 表
  const username = req.query.username;
  if (username) {
    sql += ` where username like '%${username}%' `;
  }
  db.query(sql, (err, results) => {
    if (err) {
      console.error('查询错误:', err);
      return res.status(500).json({ error: '数据库查询错误' });
    }
    res.json(results); // 返回用户数据
  });
});

// 删除用户
app.delete('/delete-user/:id', (req, res) => {
  const userId = req.params.id;
  const sql = 'DELETE FROM user WHERE id = ?';
  db.query(sql, [userId], (err, results) => {
    if (err) {
      console.error('删除错误:', err);
      return res.status(500).json({ success: false });
    }
    res.json({ success: true });
  });
});

// 修改用户密码
app.put('/edit-password/:id', (req, res) => {
  const userId = req.params.id;
  const oldPassword = req.body.oldpassword;
  const newPassword = req.body.password;
  console.log('edit-password', userId, oldPassword, newPassword)
  // 查询用户
  const selquery = `select count(1) as count from user where id=? and password = ?`;
  db.query(selquery, [userId, oldPassword], (err, result) => {
    console.log('result', result)
    if (result[0].count == 0) {
      return res.status(500).json({ error: '更新密码失败,原密码错误！' });
    }
    // 更新数据库中的用户密码
    const query = 'UPDATE user SET password = ? WHERE id = ? and password = ?';
    db.query(query, [newPassword, userId, oldPassword], (err, result) => {
      if (err) {
        return res.status(500).json({ error: '更新密码失败' });
      }
      res.json({ success: true });
    });
  });
});

// 修改用户密码
app.put('/admin/edit-password/:id', (req, res) => {
  const userId = req.params.id;
  const newPassword = req.body.password;
  console.log('edit-password', userId, newPassword)
  // 更新数据库中的用户密码
  const query = 'UPDATE user SET password = ? WHERE id = ? ';
  db.query(query, [newPassword, userId], (err, result) => {
    if (err) {
      return res.status(500).json({ error: '更新密码失败' });
    }
    res.json({ success: true });
  });
});

// 修改用户信息
app.put('/edit-user/:id', (req, res) => {
  const userId = req.params.id;
  const motto = req.body.motto;
  console.log('edit-user', userId, motto)
  // 更新数据库中的用户密码
  const query = 'UPDATE user SET motto = ? WHERE id = ?';
  db.query(query, [motto, userId], (err, result) => {
    if (err) {
      return res.status(500).json({ error: '更新用户信息失败' });
    }
    res.json({ success: true });
  });
});


// 添加留言
app.post('/api/comments', (req, res) => {
  const { user_id, title, content, remark } = req.body;
  console.log('req.body', req.body);
  const sql = 'INSERT INTO comments (user_id, title, content, time, remark) VALUES (?, ?, ?, NOW(), ?)';
  console.log(sql);
  db.query(sql, [user_id, title, content, remark], (err, result) => {
    if (err) {
      // console.error('留言失败:', err);
      return res.status(500).json({ message: '留言失败' });
    }
    console.log('留言成功:', result);
    res.status(200).json({ message: '留言成功', commentId: result.insertId });
  });
});

// 获取留言
app.get('/api/comments/:id', (req, res) => {
  const id = req.params.id;
  const sql = `
       SELECT c.id, u.username, c.title, c.content, c.time, c.remark
        FROM comments c
        JOIN user u ON c.user_id = u.id
        where c.id = ?
    `;
  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error('查询留言失败:', err);
      return res.status(500).json(err);
    }
    console.log('查询到留言:', results);
    res.status(200).json(results);
  });
});

// 获取个人的用户信息
app.get('/api/my_comments', (req, res) => {
  const userId = req.query.userId;
  console.log('req.query', req.query)
  const sql = `
        SELECT c.id, u.username, c.title, c.content, c.time, c.remark
        FROM comments c
        JOIN user u ON c.user_id = u.id
        where u.id = ?
        order by c.time desc;
    `;
  console.log('sql', sql)
  db.query(sql, [userId], (err, results) => {
    if (err) {
      console.error('查询留言失败:', err);
      return res.status(500).json(err);
    }
    console.log('查询到留言:', results);
    res.status(200).json(results);
  });
});

// 获取所有留言及用户信息
app.get('/api/comments', (req, res) => {
  const sql = `
        SELECT c.id, u.username, c.title, c.content, c.time, c.remark
        FROM comments c
        JOIN user u ON c.user_id = u.id
        order by c.time desc;
    `;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('查询留言失败:', err);
      return res.status(500).json(err);
    }
    console.log('查询到留言:', results);
    res.status(200).json(results);
  });
});

// 管理员回复留言
app.post('/api/reply', (req, res) => {
  console.log('api..reply')
  const { admin_id, comment_id, reply_content } = req.body;
  console.log('req.body', req.body)
  const sql = 'INSERT INTO replies (comment_id, admin_id, reply_content, reply_time) VALUES (?, ?, ?, NOW())';
  db.query(sql, [comment_id, admin_id, reply_content], (err, result) => {
    if (err) {
      console.error('回复失败:', err);
      return res.status(500).json({ message: '回复失败' });
    }
    console.log('回复成功:', result);
    res.status(200).json({ message: '回复成功', replyId: result.insertId });
  });
});

// 获取所有留言及管理员的回复
app.get('/api/comments_with_replies', (req, res) => {
  const comment_id = req.query.cid;
  let sql = `
        SELECT c.id AS comment_id, u.username, c.title, c.content, c.time, c.remark, 
               r.reply_content, r.reply_time,r.admin_id
        FROM comments c
        JOIN user u ON c.user_id = u.id
        LEFT JOIN replies r ON c.id = r.comment_id
    `;
  if (comment_id) {
    sql += ` where c.id = ${comment_id} `
  }
  console.log('req.query', req.query);
  console.log('sql', sql);
  db.query(sql, (err, results) => {
    if (err) {
      console.error('查询留言和回复失败:', err);
      return res.status(500).json(err);
    }
    console.log('查询到留言及回复:', results);
    res.status(200).json(results);
  });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
});