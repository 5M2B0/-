use library;

db.books.insertMany([
  {
    "_id": ObjectId(),
    "name": "世界很喧嚣，做自己就好",
    "quantity": 10,
    "author": "老杨的猫头鹰",
    "category": "文学",
    "remark": "书籍"
  },
  {
    "_id": ObjectId(),
    "name": "十万个为什么",
    "quantity": 10,
    "author": "匿名",
    "category": "科学",
    "remark": "书籍"
  }
]);

db.book_reservations.insertMany([
  {
    "_id": ObjectId(),
    "user_id": null,
    "book_id": null,
    "reservation_time": new Date(),
    "status": "预约中",
    "remark": null
  }
]);



db.borrow_records.insertMany([
  {
    "_id": ObjectId(),
    "user_id": 10,
    "book_id": 5,
    "book_name": null,
    "borrow_time": "2024/10/18 15:22:25",
    "return_time": "2024/10/18 15:24:47",
    "author": null,
    "category": null,
    "remark": null,
    "action": null,
    "status": "已还"
  },
  {
    "_id": ObjectId(),
    "user_id": 10,
    "book_id": 5,
    "book_name": null,
    "borrow_time": "2024/10/18 15:25:01",
    "return_time": "2024/10/18 15:25:19",
    "author": null,
    "category": null,
    "remark": null,
    "action": null,
    "status": "已还"
  }
]);


db.comments.insertMany([
  {
    "_id": ObjectId(),
    "user_id": 10,
    "title": "留言标题",
    "content": "11",
    "time": "2024-10-18 09:55:44",
    "remark": null
  },
  {
    "_id": ObjectId(),
    "user_id": 10,
    "title": "留言标题",
    "content": "111",
    "time": "2024-10-18 10:31:13",
    "remark": null
  },
  {
    "_id": ObjectId(),
    "user_id": 10,
    "title": "留言标题",
    "content": "这是用户的留言",
    "time": "2024-10-18 16:52:39",
    "remark": null
  }
]);


db.replies.insertMany([
  {
    "_id": ObjectId(),
    "comment_id": 22,
    "admin_id": null,
    "reply_content": "2222",
    "reply_time": "2024-10-18 16:38:06"
  },
  {
    "_id": ObjectId(),
    "comment_id": 22,
    "admin_id": null,
    "reply_content": "3333",
    "reply_time": "2024-10-18 16:38:11"
  },
  {
    "_id": ObjectId(),
    "comment_id": 23,
    "admin_id": null,
    "reply_content": "22",
    "reply_time": "2024-10-18 16:48:23"
  },
  {
    "_id": ObjectId(),
    "comment_id": 23,
    "admin_id": null,
    "reply_content": "333",
    "reply_time": "2024-10-18 16:48:30"
  },
  {
    "_id": ObjectId(),
    "comment_id": 23,
    "admin_id": null,
    "reply_content": "",
    "reply_time": "2024-10-18 16:48:41"
  },
  {
    "_id": ObjectId(),
    "comment_id": 22,
    "admin_id": null,
    "reply_content": "444",
    "reply_time": "2024-10-18 16:49:25"
  },
  {
    "_id": ObjectId(),
    "comment_id": 24,
    "admin_id": null,
    "reply_content": "我是管理员",
    "reply_time": "2024-10-18 16:53:03"
  }
]);


db.user.insertMany([
  {
    "_id": ObjectId(),
    "username": "123",
    "password": "1",
    "motto": null
  },
  {
    "_id": ObjectId(),
    "username": "qwe",
    "password": "1",
    "motto": "111222333"
  },
  {
    "_id": ObjectId(),
    "username": "aa",
    "password": "1",
    "motto": null
  },
  {
    "_id": ObjectId(),
    "username": "vv",
    "password": "33",
    "motto": null
  }
]);
